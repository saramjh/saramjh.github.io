---
title: Acknowledgment
permalink: /thanks/
layout: page
excerpt: Thanks to amazing people that i met, who help me out from follishness, connecting me with another good person, giving some advice when i'm at a bad things, pulling me from ordinary to be great.
comments: false
---

Thanks to amazing people that i met, who help me out from follishness, connecting me with another good person, giving some advice when i'm at a bad things, pulling me from ordinary to be great.

<hr>

Hopefully the knowledge that I got from them can be useful, and become a charity for them, Aamiin.
