# Become a contributor
- Fork
- Create new branch, representing the changes
- Make changes, ensure it's working
- Push your own repo 
- Create PR, describe your changes 
- Thank You
